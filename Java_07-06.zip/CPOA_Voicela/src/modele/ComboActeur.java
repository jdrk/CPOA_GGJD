/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

import DA.DaoNationalite;
import DA.DaoVip;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.AbstractListModel;
import javax.swing.ComboBoxModel;
import metier.Nationalite;
import metier.Vip;

/**
 *
 * @author Guillaume
 */
public class ComboActeur extends AbstractListModel implements ComboBoxModel  {
    
    private ArrayList<Vip> listeActeur;
    private String selection = "Choisir un acteur";
    private DaoVip objetVip;
    
    public ComboActeur(DaoVip daoVip){
        this.listeActeur = new ArrayList<>();
        this.objetVip = daoVip;
    }
    
    public void loadActeur() throws SQLException{
        objetVip.lireActeur(listeActeur);
    }

    @Override
    public int getSize() {
        return listeActeur.size();
        
    }

    @Override
    public Object getElementAt(int index) {
        String acteur = listeActeur.get(index).getNumVip() + " - " + listeActeur.get(index).getNomVip() + " " + listeActeur.get(index).getPrenomVip();
        
        return acteur;
    }

    @Override
    public void setSelectedItem(Object anItem) {
        selection = (String) anItem;
    }

    @Override
    public Object getSelectedItem() {
        return selection;
    }
    
}