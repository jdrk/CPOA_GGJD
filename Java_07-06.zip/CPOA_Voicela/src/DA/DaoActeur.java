/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DA;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import metier.Acteur;

/**
 *
 * @author Guillaume
 */
public class DaoActeur {
    
    private final Connection connexion;
   // private static String numVip; // utilisé pour transmettre le dernier numéroVip
    
    public DaoActeur(Connection connexion) throws SQLException{
        this.connexion = connexion;
    }
    
    public void lireActeur(ArrayList<Acteur> listeActeur, String numVisa) throws SQLException{ 
        String requete = "SELECT * FROM ACTEUR WHERE NUMVISA = " + numVisa ;
        PreparedStatement pstmt = connexion.prepareStatement(requete);
        ResultSet rset = pstmt.executeQuery(requete);
        Acteur acteur;
        while (rset.next()) {
            String numVip = rset.getString(1);
            String numVisa1 = rset.getString(2);
            acteur = new Acteur(numVip, numVisa1);
            listeActeur.add(acteur);
        }
        rset.close();
        pstmt.close();   
    }
    
    public void addActeur(String numVip, String numVisa) throws SQLException{
        String requete = "INSERT INTO ACTEUR VALUES(?,?)";
        PreparedStatement pstmt = connexion.prepareStatement(requete);
        pstmt.setString(1, numVip);
        pstmt.setString(2, numVisa);
        pstmt.executeUpdate();
        pstmt.close();
      
        
    }
    
    public void suppActeur(String numVip) throws SQLException{
        String requete = "DELETE FROM ACTEUR WHERE NUMVIP = " + numVip;
        PreparedStatement pstmt = connexion.prepareStatement(requete);
        pstmt.executeUpdate();
        pstmt.close();
    }
    
    
    public Acteur getActeur(String numVip) throws SQLException{ 
        String requete = "SELECT * FROM ACTEUR WHERE NUMVIP = " + numVip ;
        PreparedStatement pstmt = connexion.prepareStatement(requete);
        ResultSet rset = pstmt.executeQuery(requete);
        Acteur acteur;
        while (rset.next()) {
            String numVip1 = rset.getString(1);
            String numVisa1 = rset.getString(2);
            acteur = new Acteur(numVip1, numVisa1);
            return acteur;
        }
        rset.close();
        pstmt.close();   
        
        return null;
    }
}
