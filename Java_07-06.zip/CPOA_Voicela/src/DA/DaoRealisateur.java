/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DA;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import metier.Acteur;
import metier.Realisateur;

/**
 *
 * @author Guillaume
 */
public class DaoRealisateur {
        private final Connection connexion;
   // private static String numVip; // utilisé pour transmettre le dernier numéroVip
    
    public DaoRealisateur(Connection connexion) throws SQLException{
        this.connexion = connexion;
    }
    
    public void lireRealisateur(ArrayList<Realisateur> listeRealisateur, String numVisa) throws SQLException{ 
        String requete = "SELECT * FROM REALISATEUR WHERE NUMVISA = " + numVisa ;
        PreparedStatement pstmt = connexion.prepareStatement(requete);
        ResultSet rset = pstmt.executeQuery(requete);
        Realisateur realisateur;
        while (rset.next()) {
            String numVip = rset.getString(1);
            String numVisa1 = rset.getString(2);
            realisateur = new Realisateur(numVip, numVisa1);
            listeRealisateur.add(realisateur);
        }
        rset.close();
        pstmt.close();   
    }
    
        public void addRealisateur(String numVip, String numVisa) throws SQLException{
        String requete = "INSERT INTO REALISATEUR VALUES(?,?)";
        PreparedStatement pstmt = connexion.prepareStatement(requete);
        pstmt.setString(1, numVip);
        pstmt.setString(2, numVisa);
        pstmt.executeUpdate();
        pstmt.close();
      
        
    }
        
    public void suppRealisateur (String numVip) throws SQLException{
        String requete = "DELETE FROM REALISATEUR WHERE NUMVIP = " + numVip;
        PreparedStatement pstmt = connexion.prepareStatement(requete);
        pstmt.executeUpdate();
        pstmt.close();
    }
    
    public Realisateur getRea (String numVip) throws SQLException {
        String requete = "SELECT * FROM REALISATEUR WHERE NUMVIP = " + numVip ;
        PreparedStatement pstmt = connexion.prepareStatement(requete);
        ResultSet rset = pstmt.executeQuery(requete);
        Realisateur realisateur;
        while (rset.next()) {
            String numVip1 = rset.getString(1);
            String numVisa1 = rset.getString(2);
            realisateur = new Realisateur(numVip1, numVisa1);
            return realisateur;
        }
        rset.close();
        pstmt.close();  
        
        return null;
        
    }
    
    
}
