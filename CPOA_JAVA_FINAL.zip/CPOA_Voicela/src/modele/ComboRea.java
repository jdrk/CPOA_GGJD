/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

import DA.DaoNationalite;
import DA.DaoVip;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.AbstractListModel;
import javax.swing.ComboBoxModel;
import metier.Nationalite;
import metier.Vip;

/**
 *
 * @author Guillaume
 */
public class ComboRea extends AbstractListModel implements ComboBoxModel  {
    
    private ArrayList<Vip> listeRea;
    private String selection = "Choisir un réalisateur";
    private DaoVip objetVip;
    
    public ComboRea(DaoVip daoVip){
        this.listeRea = new ArrayList<>();
        this.objetVip = daoVip;
    }
    
    public void loadRealisateur() throws SQLException{
        objetVip.lireRealisateur(listeRea);
    }
    
    public void unload(){
        listeRea.clear();
    }

    @Override
    public int getSize() {
        return listeRea.size();
        
    }

    @Override
    public Object getElementAt(int index) {
        String acteur = listeRea.get(index).getNumVip() + " - " + listeRea.get(index).getNomVip() + " " + listeRea.get(index).getPrenomVip();
        
        return acteur;
    }

    @Override
    public void setSelectedItem(Object anItem) {
        selection = (String) anItem;
    }

    @Override
    public Object getSelectedItem() {
        return selection;
    }
    
}