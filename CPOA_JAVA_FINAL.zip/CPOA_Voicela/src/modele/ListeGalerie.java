/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

import DA.DaoVip;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.AbstractListModel;
import metier.Photo;
import metier.Vip;

/**
 *
 * @author Guillaume
 */
public class ListeGalerie extends AbstractListModel {
    
    
    private ArrayList<Photo> listePhoto;
    private Photo photo;
    private DaoVip daoVip;
    
    public ListeGalerie(DaoVip daoVip) throws SQLException{
        this.listePhoto = new ArrayList<Photo>();
        
        this.daoVip = daoVip;
    
    }
    
    public void addToGalerie(Photo photo) throws SQLException{
        this.photo = photo;
        daoVip.addToGalerie(photo);
        listePhoto.add(photo);

        this.fireContentsChanged(this, 0, 99);
    }
   

    @Override
    public int getSize() {
        return listePhoto.size();
    }

    @Override
    public Object getElementAt(int index) {
        String numVip2 = listePhoto.get(index).getNumVip();
        
        try {
            Vip leVip = daoVip.getVip(numVip2);
            return leVip.getNumVip() + " - " + leVip.getNomVip() + " " + leVip.getPrenomVip();
        } catch (SQLException ex) {
            Logger.getLogger(ListeGalerie.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return numVip2;

    }
    
}
