
package modele;

import DA.DaoActeur;
import DA.DaoVip;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.AbstractListModel;
import metier.Acteur;
import metier.Vip;


public class ListeActeur extends AbstractListModel {

    private ArrayList<Acteur> listeActeur;
    private DaoActeur daoActeur;
    private DaoVip daoVip;

    public ListeActeur(DaoActeur daoActeur, DaoVip daoVip) throws SQLException  {
        this.listeActeur = new ArrayList<>();       
        this.daoActeur = daoActeur;
        this.daoVip = daoVip;
    }
    
    public void getListeActeur(String numVisa) throws SQLException{
        daoActeur.lireActeur(listeActeur, numVisa);
        this.fireContentsChanged(this, 0, 99);
    }
    
    public void addAct(String numVip, String numVisa) throws SQLException{
        daoActeur.addActeur(numVip, numVisa);
        Acteur temp = new Acteur(numVip, numVisa);
        listeActeur.add(temp);
        this.fireContentsChanged(this, 0, 99);
        
    }
    
    
    public void suppAct(String numVip) throws SQLException{
        daoActeur.suppActeur(numVip);
        Acteur act = daoActeur.getActeur(numVip);
        listeActeur.remove(act);
        this.fireContentsChanged(this, 0, 99);
    }
    
    public void clearList(){
        listeActeur.clear();
    }
    
    @Override
    public int getSize() {
        return listeActeur.size();
    }

    @Override
    public Object getElementAt(int i) {
        String numVip = listeActeur.get(i).getNumVip(); 
        Vip temp;
        try {
            temp = daoVip.getVip(numVip);
            return numVip + " - " + temp.getNomVip() + " " + temp.getPrenomVip();
        } catch (SQLException ex) {
            Logger.getLogger(ListeActeur.class.getName()).log(Level.SEVERE, null, ex);
            return "Erreur sur la personne !";
        }
        
        //return null;
    }

    

} 
