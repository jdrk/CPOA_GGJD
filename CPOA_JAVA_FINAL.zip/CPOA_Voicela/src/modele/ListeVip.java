/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

import DA.DaoVip;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.AbstractListModel;
import metier.Vip;

/**
 *
 * @author Guillaume
 */
public class ListeVip extends AbstractListModel {
    
    private ArrayList<Vip> listeVip;
    private DaoVip daoVip;
    
    public ListeVip(DaoVip daoVip) throws SQLException{
        this.listeVip = new ArrayList<Vip>();
        this.daoVip = daoVip;
    
    }
    
    public void getListVip() throws SQLException{
        daoVip.lireVip(listeVip);
        this.fireContentsChanged(this, 0, 99);
    }
    
    public void unload(){
        listeVip.clear();
    }
    

    @Override
    public int getSize() {
        return listeVip.size();
    }

    @Override
    public Object getElementAt(int index) {
        Vip leVip = listeVip.get(index);
        return leVip.getNumVip() + " - " + leVip.getNomVip() + " " + leVip.getPrenomVip();
    }
    
    
    
}
