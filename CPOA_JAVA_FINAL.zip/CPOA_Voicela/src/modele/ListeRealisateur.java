/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

import DA.DaoRealisateur;
import DA.DaoVip;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.AbstractListModel;
import metier.Acteur;
import metier.Realisateur;
import metier.Vip;

/**
 *
 * @author Guillaume
 */
public class ListeRealisateur extends AbstractListModel{    
    
    private ArrayList<Realisateur> listeRealisateur;
    private DaoRealisateur daoRealisateur;
    private DaoVip daoVip;
    
    public ListeRealisateur(DaoRealisateur daoRea, DaoVip daoVip) throws SQLException  {
        this.listeRealisateur = new ArrayList<>();       
        this.daoRealisateur = daoRea;
        this.daoVip = daoVip;
    }
    
    public void getListeRealisateur(String numVisa) throws SQLException{
        daoRealisateur.lireRealisateur(listeRealisateur, numVisa);
        this.fireContentsChanged(this, 0, 99);
    }
    
    public void clearList(){
        listeRealisateur.clear();
    }
    
    public void addRea(String numVip, String numVisa) throws SQLException{
        daoRealisateur.addRealisateur(numVip, numVisa);
        Realisateur rea = new Realisateur(numVip, numVisa);
        listeRealisateur.add(rea);
        this.fireContentsChanged(this, 0, 99);
        
    }
  
    public void suppRealisateur(String numVip) throws SQLException{
        daoRealisateur.suppRealisateur(numVip);
        Realisateur rea = daoRealisateur.getRea(numVip);
        listeRealisateur.remove(rea);
        this.fireContentsChanged(this, 0, 99);
    }
    @Override
    public int getSize() {
        return listeRealisateur.size();
    }

    @Override
    public Object getElementAt(int i) {
        String numVip = listeRealisateur.get(i).getNumVip(); 
        
        Vip temp;
        try {
            temp = daoVip.getVip(numVip);
            return numVip + " - " + temp.getNomVip() + " " + temp.getPrenomVip();
        } catch (SQLException ex) {
            Logger.getLogger(ListeActeur.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return null;
    }
    
}
