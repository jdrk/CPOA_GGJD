/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

import DA.DaoGenre;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.AbstractListModel;
import javax.swing.ComboBoxModel;
import metier.Genre;

/**
 *
 * @author Guillaume
 */
public class ComboGenre extends AbstractListModel implements ComboBoxModel {
    
    private ArrayList<Genre> listeGenre;
    private String selection = "01 - Action";
    private DaoGenre daoGenre;
    
    public ComboGenre(DaoGenre daoGenre){
        this.listeGenre = new ArrayList<>();
        this.daoGenre = daoGenre;
    }

    public void loadGenre() throws SQLException{
        daoGenre.lireGenre(listeGenre);
    }
    
    
    
    @Override
    public int getSize() {
        return listeGenre.size();
    }

    @Override
    public Object getElementAt(int index) {
       String genre = listeGenre.get(index).getIdGenre() + " - " + listeGenre.get(index).getLibbeleGenre();
       return genre;
    }

    @Override
    public void setSelectedItem(Object anItem) {
        selection = (String) anItem;
    }

    @Override
    public Object getSelectedItem() {
        return selection;
    }
    
}
