/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metier;

/**
 *
 * @author Guillaume
 */
public class Photo {
    
    private String numVip;
    private String idPhoto;
    private String datePhoto;
    private String lieuPhoto;

    public Photo(String numVip, String idPhoto, String datePhoto, String lieuPhoto) {
        this.numVip = numVip;
        this.idPhoto = idPhoto;
        this.datePhoto = datePhoto;
        this.lieuPhoto = lieuPhoto;
    }

    public String getNumVip() {
        return numVip;
    }

    public void setNumVip(String numVip) {
        this.numVip = numVip;
    }

    public String getIdPhoto() {
        return idPhoto;
    }

    public void setIdPhoto(String idPhoto) {
        this.idPhoto = idPhoto;
    }

    public String getDatePhoto() {
        return datePhoto;
    }

    public void setDatePhoto(String datePhoto) {
        this.datePhoto = datePhoto;
    }

    public String getLieuPhoto() {
        return lieuPhoto;
    }

    public void setLieuPhoto(String lieuPhoto) {
        this.lieuPhoto = lieuPhoto;
    }

    @Override
    public String toString() {
        return "Photo{" + "numVip=" + numVip + ", idPhoto=" + idPhoto + ", datePhoto=" + datePhoto + ", lieuPhoto=" + lieuPhoto + '}';
    }
    
    
    
}
