/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metier;

/**
 *
 * @author Guillaume
 */
public class Realisateur {
    
    private String numVip;
    private String numVisa;

    public Realisateur(String numVip, String numVisa) {
        this.numVip = numVip;
        this.numVisa = numVisa;
    }

    public String getNumVip() {
        return numVip;
    }

    public void setNumVip(String numVip) {
        this.numVip = numVip;
    }

    public String getNumVisa() {
        return numVisa;
    }

    public void setNumVisa(String numVisa) {
        this.numVisa = numVisa;
    }

    @Override
    public String toString() {
        return "Realisateur{" + "numVip=" + numVip + ", numVisa=" + numVisa + '}';
    }
    
    
    
}
