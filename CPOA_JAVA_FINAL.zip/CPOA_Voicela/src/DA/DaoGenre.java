/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DA;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import metier.Genre;

/**
 *
 * @author Guillaume
 */
public class DaoGenre {
    
    private final Connection connexion;

    public DaoGenre(Connection c){
        this.connexion=c;
    }
    
    public void lireGenre(ArrayList<Genre> listeGenre) throws SQLException{
        String requete = "SELECT * FROM GENRE";
        PreparedStatement pstmt = connexion.prepareStatement(requete);
        ResultSet rset = pstmt.executeQuery(requete);
        Genre leGenre;
        while(rset.next()){
            String idGenre = rset.getString(1);
            String nomGenre = rset.getString(2);
            leGenre = new Genre(idGenre,nomGenre);
            System.out.println(leGenre);
            listeGenre.add(leGenre);
        }
        rset.close();
        pstmt.close();
    
    }
    
    public String getSelectedGenre(String id) throws SQLException{
        String requete = "SELECT libelleGenre FROM GENRE WHERE idGenre = '" + id + "'";
        PreparedStatement pstmt = connexion.prepareStatement(requete);
        ResultSet rset = pstmt.executeQuery(requete);
        String nomGenre = null;
        while(rset.next()){
            nomGenre = rset.getString(1);
            
        }
        rset.close();
        pstmt.close();
        return id + " - " + nomGenre;
    }
   
}
