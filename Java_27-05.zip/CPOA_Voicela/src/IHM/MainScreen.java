/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IHM;

import DA.DaoEvenement;
import DA.DaoVip;
import DA.FTPManager;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import metier.Evenement;
import metier.Film;
import modele.ModeleVip;
import metier.Vip;
import modele.ModeleFilm;
import modele.ModeleNat;
import modele.ModeleVipEvent;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPSClient;

/**
 *
 * @author Guillaume
 */
public class MainScreen extends javax.swing.JFrame {

    private ModeleVip modeleVip;
    private ModeleNat modeleNat;
    private ModeleFilm modeleFilm;
    private ModeleVipEvent modeleVipEvent;
    private Connection connexion;
    private DaoEvenement daoEvent;
    private Vip leVip;
    private DaoVip daoVip;
    private static int lastNumVip;
    /**
     * Creates new form Tabulado
     */
    
    String server = "iutdoua-samba.univ-lyon1.fr";
    int port = 990;
    String user = "p1422528";
    String pass = "NANAlove0604";
    public MainScreen(ModeleVip modeleVip, String baseName, ModeleNat modeleNat, ModeleFilm modeleFilm, ModeleVipEvent modeleVipEvent, DaoEvenement daoEvent, DaoVip daoVip) throws SQLException {
        this.modeleVip = modeleVip;
        this.modeleNat = modeleNat;
        this.modeleFilm = modeleFilm;
        this.modeleVipEvent = modeleVipEvent;
        this.daoEvent = daoEvent;
        this.daoVip = daoVip;
        initComponents();
        
//        FTPSClient ftpClient = new FTPSClient();
//        
//        try {
// 
//            ftpClient.connect(server, port);
//            ftpClient.login(user, pass);
//            ftpClient.enterLocalPassiveMode();
//            
// 
//            //ftpClient.setFileType(FTP.BINARY_FILE_TYPE);
//            ftpClient.setFileType(FTP.BINARY_FILE_TYPE, FTP.BINARY_FILE_TYPE);
//            ftpClient.setFileTransferMode(FTP.BINARY_FILE_TYPE);
// 
//            // APPROACH #1: uploads first file using an InputStream
//            File firstLocalFile = new File("C:\\Users\\Guillaume\\Documents\\tp1.odt");
// 
//            String firstRemoteFile = "tp1.odt";
//            InputStream inputStream = new FileInputStream(firstLocalFile);
// 
//            System.out.println("Début de l'upload du fichier ... ");
//            boolean done = ftpClient.storeFile(firstRemoteFile, inputStream);
//            inputStream.close();
//            if (done) {
//                System.out.println("Upload réussi ! ");
//            } else {
//                System.out.println("Erreur lors de l'upload !");
//            }
// 
//            // APPROACH #2: uploads second file using an OutputStream
//            
///*            
//            File secondLocalFile = new File("E:/Test/Report.doc");
//            String secondRemoteFile = "test/Report.doc";
//            inputStream = new FileInputStream(secondLocalFile);
// 
//            System.out.println("Start uploading second file");
//            OutputStream outputStream = ftpClient.storeFileStream(secondRemoteFile);
//            byte[] bytesIn = new byte[4096];
//            int read = 0;
// 
//            while ((read = inputStream.read(bytesIn)) != -1) {
//                outputStream.write(bytesIn, 0, read);
//            }
//            inputStream.close();
//            outputStream.close();
// 
//            boolean completed = ftpClient.completePendingCommand();
//            if (completed) {
//                System.out.println("The second file is uploaded successfully.");
//            }
// */
//        } catch (IOException ex) {
//            System.out.println("Error: " + ex.getMessage());
//            ex.printStackTrace();
//        } finally {
//            try {
//                if (ftpClient.isConnected()) {
//                    ftpClient.logout();
//                    ftpClient.disconnect();
//                }
//            } catch (IOException ex) {
//                ex.printStackTrace();
//            }
//        }
//        

        

        try {
            
        } catch (Exception ex) {
            Logger.getLogger(MainScreen.class.getName()).log(Level.SEVERE, null, ex);
        }

        modeleNat.loadNat();
        
        this.baseNameTxt.setText(baseName);
       /* for(String m : ModeleNat){
           nationaliteVipbox.add(m); 
        }*/
        
       
       
        try {
            lastNumVip = Integer.parseInt(modeleVip.loadVip()) + 1; //effectue implicitement le loadVip()
            numViptxt.setText("0"+String.valueOf(lastNumVip));
            modeleFilm.loadFilm();
            modeleVipEvent.loadVip();
        } catch (SQLException ex) {
            Logger.getLogger(MainScreen.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jSeparator1 = new javax.swing.JSeparator();
        eventTab = new javax.swing.JTabbedPane();
        vipPanel = new javax.swing.JPanel();
        numVip = new javax.swing.JLabel();
        nomVip = new javax.swing.JLabel();
        prenomVip = new javax.swing.JLabel();
        numViptxt = new javax.swing.JTextField();
        nomViptxt = new javax.swing.JTextField();
        prenomViptxt = new javax.swing.JTextField();
        civiliteVip = new javax.swing.JLabel();
        civiliteVipbox = new javax.swing.JComboBox<>();
        naissanceVip = new javax.swing.JLabel();
        roleVip = new javax.swing.JLabel();
        roleVipbox = new javax.swing.JComboBox<>();
        nationaliteVip = new javax.swing.JLabel();
        nationaliteVipbox = new javax.swing.JComboBox<>();
        statutVip = new javax.swing.JLabel();
        statutVipbox = new javax.swing.JComboBox<>();
        addBtn = new javax.swing.JButton();
        resetBtn = new javax.swing.JButton();
        datenaissanceVip = new javax.swing.JTextField();
        addBaselbl = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        delBtn = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        naissanceVip1 = new javax.swing.JLabel();
        svBtn = new javax.swing.JButton();
        svLb = new javax.swing.JLabel();
        saveBtn = new javax.swing.JButton();
        sauvegarderTxt = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableVip = new javax.swing.JTable();
        jScrollPane3 = new javax.swing.JScrollPane();
        infoVipPanel = new javax.swing.JTextArea();
        infoLogo = new javax.swing.JLabel();
        addVipBorder = new javax.swing.JPanel();
        indicatorVipLabel = new javax.swing.JLabel();
        jSeparator3 = new javax.swing.JSeparator();
        naissanceViptxt = new com.toedter.calendar.JDateChooser();
        photoPanel = new javax.swing.JPanel();
        importPhotos = new javax.swing.JButton();
        pathField = new javax.swing.JTextField();
        etatUpload = new javax.swing.JLabel();
        eventPanel = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jSeparator6 = new javax.swing.JSeparator();
        panelCelib = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        applyThis = new javax.swing.JButton();
        jSeparator8 = new javax.swing.JSeparator();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        lieuTxt = new javax.swing.JTextField();
        dateMtxt = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        dateDtxt = new javax.swing.JTextField();
        nomVipE = new javax.swing.JTextField();
        nomVipE2 = new javax.swing.JTextField();
        typeEvent = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        applyEvent = new javax.swing.JButton();
        resetEvent = new javax.swing.JButton();
        jScrollPane12 = new javax.swing.JScrollPane();
        tableEvent = new javax.swing.JTable();
        modifierVip1 = new javax.swing.JButton();
        modifierVip2 = new javax.swing.JButton();
        filmPanel = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tableFilm = new javax.swing.JTable();
        delFilmBtn = new javax.swing.JButton();
        delBase = new javax.swing.JLabel();
        modifyFilm = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        addVipBorder1 = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        infoVipPanel1 = new javax.swing.JTextArea();
        infoLogo1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        numVisa = new javax.swing.JLabel();
        titreFilm = new javax.swing.JLabel();
        genreFilm = new javax.swing.JLabel();
        anneeSortie = new javax.swing.JLabel();
        numVisatxt = new javax.swing.JTextField();
        titreFilmtxt = new javax.swing.JTextField();
        genreFilmbox = new javax.swing.JComboBox<>();
        anneeSortietxt = new javax.swing.JTextField();
        addFilmBtn = new javax.swing.JButton();
        addBase = new javax.swing.JLabel();
        validateFilm = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane8 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jButton4 = new javax.swing.JButton();
        indicatorVipLabel1 = new javax.swing.JLabel();
        jSeparator4 = new javax.swing.JSeparator();
        jPanel1 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jScrollPane10 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList<>();
        jLabel7 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox<>();
        jScrollPane11 = new javax.swing.JScrollPane();
        jList5 = new javax.swing.JList<>();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jSeparator5 = new javax.swing.JSeparator();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        acteurPanel = new javax.swing.JPanel();
        lblDispo2 = new javax.swing.JLabel();
        reaPanel = new javax.swing.JPanel();
        lblDispo1 = new javax.swing.JLabel();
        topPanel = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        baseNameTxt = new javax.swing.JLabel();
        baseIndicTxt = new javax.swing.JLabel();
        borderLeftYellowPanel = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("VoiceLa Administration Tool");
        setResizable(false);

        eventTab.setBackground(new java.awt.Color(51, 0, 153));

        numVip.setText("Numéro VIP");

        nomVip.setText("Nom");

        prenomVip.setText("Prénom");

        numViptxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                numViptxtActionPerformed(evt);
            }
        });

        nomViptxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nomViptxtActionPerformed(evt);
            }
        });

        civiliteVip.setText("Civilité");

        civiliteVipbox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "M - Masculin", "F - Féminin" }));
        civiliteVipbox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                civiliteVipboxActionPerformed(evt);
            }
        });

        naissanceVip.setText("Lieu de Naissance");

        roleVip.setText("Rôle");

        roleVipbox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "AC - Acteur", "RE - Réalisateur", "AR - Acteur & Réalisateur" }));
        roleVipbox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                roleVipboxActionPerformed(evt);
            }
        });

        nationaliteVip.setText("Nationalité");

        nationaliteVipbox.setModel(modeleNat);
        nationaliteVipbox.setSelectedItem("FR - Française");
        nationaliteVipbox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nationaliteVipboxActionPerformed(evt);
            }
        });

        statutVip.setText("Statut  (à récupérer)");

        statutVipbox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "M - Marié", "D - Divorcé", "C - Célibataire" }));
        statutVipbox.setEnabled(false);
        statutVipbox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                statutVipboxActionPerformed(evt);
            }
        });

        addBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cross.png"))); // NOI18N
        addBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        addBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addBtnActionPerformed(evt);
            }
        });

        resetBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/arrows.png"))); // NOI18N
        resetBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetBtnActionPerformed(evt);
            }
        });

        addBaselbl.setText("Ajouter à la base");

        jLabel2.setText("Réinitialiser les champs/actualiser la vue/annuler");

        delBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/delete.png"))); // NOI18N
        delBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delBtnActionPerformed(evt);
            }
        });

        jLabel3.setText("Supprimer l'élément sélectionné");

        naissanceVip1.setText("Date de Naissance");

        svBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/content-save.png"))); // NOI18N
        svBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        svBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                svBtnActionPerformed(evt);
            }
        });

        svLb.setText("Modifier un élément");

        saveBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/content-save.png"))); // NOI18N
        saveBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        saveBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveBtnActionPerformed(evt);
            }
        });

        sauvegarderTxt.setText("Sauvegarder les modifications");

        jScrollPane1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        tableVip.setForeground(new java.awt.Color(51, 51, 51));
        tableVip.setModel(modeleVip);
        tableVip.setAlignmentX(1.0F);
        tableVip.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        tableVip.setDragEnabled(true);
        jScrollPane1.setViewportView(tableVip);

        infoVipPanel.setEditable(false);
        infoVipPanel.setBackground(new java.awt.Color(240, 240, 240));
        infoVipPanel.setColumns(20);
        infoVipPanel.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        infoVipPanel.setLineWrap(true);
        infoVipPanel.setRows(5);
        infoVipPanel.setText("VoiceLa Administration Tool vous donne la possibilité d'effectuer \nmultiples manipulations de vos VIP ! Le processus de mise en forme\nest automatisée par le site. Vous pouvez ajouter un VIP, supprimer \net même editer les informations d'un VIP ! Pour ajouter une photo à \nvotre VIP, rendez-vous dans l'onglet \"Photo\". ");
        infoVipPanel.setToolTipText("");
        jScrollPane3.setViewportView(infoVipPanel);

        infoLogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/info-icone-5376-48.png"))); // NOI18N

        addVipBorder.setBackground(new java.awt.Color(102, 0, 102));

        javax.swing.GroupLayout addVipBorderLayout = new javax.swing.GroupLayout(addVipBorder);
        addVipBorder.setLayout(addVipBorderLayout);
        addVipBorderLayout.setHorizontalGroup(
            addVipBorderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        addVipBorderLayout.setVerticalGroup(
            addVipBorderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        indicatorVipLabel.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        indicatorVipLabel.setText("Ajouter ou Modifier un VIP");

        naissanceViptxt.setDateFormatString("YYYY-MM-dd");

        javax.swing.GroupLayout vipPanelLayout = new javax.swing.GroupLayout(vipPanel);
        vipPanel.setLayout(vipPanelLayout);
        vipPanelLayout.setHorizontalGroup(
            vipPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(vipPanelLayout.createSequentialGroup()
                .addGroup(vipPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(vipPanelLayout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(infoLogo))
                    .addComponent(addVipBorder, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22)
                .addGroup(vipPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 414, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(vipPanelLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(vipPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(vipPanelLayout.createSequentialGroup()
                                .addComponent(nomVip)
                                .addGap(127, 127, 127)
                                .addComponent(nomViptxt, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(vipPanelLayout.createSequentialGroup()
                                .addComponent(prenomVip)
                                .addGap(112, 112, 112)
                                .addComponent(prenomViptxt, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(vipPanelLayout.createSequentialGroup()
                                .addComponent(naissanceVip)
                                .addGap(63, 63, 63)
                                .addComponent(datenaissanceVip, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(vipPanelLayout.createSequentialGroup()
                                .addComponent(roleVip)
                                .addGap(127, 127, 127)
                                .addComponent(roleVipbox, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(vipPanelLayout.createSequentialGroup()
                                .addComponent(addBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(14, 14, 14)
                                .addComponent(addBaselbl)
                                .addGap(38, 38, 38)
                                .addComponent(saveBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(sauvegarderTxt))
                            .addComponent(indicatorVipLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(vipPanelLayout.createSequentialGroup()
                                .addComponent(numVip)
                                .addGap(92, 92, 92)
                                .addComponent(numViptxt, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 364, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 405, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(vipPanelLayout.createSequentialGroup()
                                .addGroup(vipPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(civiliteVip)
                                    .addComponent(naissanceVip1))
                                .addGap(59, 59, 59)
                                .addGroup(vipPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(civiliteVipbox, 0, 189, Short.MAX_VALUE)
                                    .addComponent(naissanceViptxt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(vipPanelLayout.createSequentialGroup()
                                .addGroup(vipPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(nationaliteVip)
                                    .addComponent(statutVip))
                                .addGap(48, 48, 48)
                                .addGroup(vipPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(statutVipbox, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(nationaliteVipbox, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addGap(60, 60, 60)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 877, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(vipPanelLayout.createSequentialGroup()
                .addGap(570, 570, 570)
                .addComponent(resetBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(9, 9, 9)
                .addComponent(jLabel2)
                .addGap(129, 129, 129)
                .addComponent(delBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(9, 9, 9)
                .addComponent(jLabel3)
                .addGap(90, 90, 90)
                .addComponent(svBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(svLb))
        );
        vipPanelLayout.setVerticalGroup(
            vipPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(vipPanelLayout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(vipPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 553, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(vipPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(vipPanelLayout.createSequentialGroup()
                            .addGap(34, 34, 34)
                            .addComponent(infoLogo)
                            .addGap(54, 54, 54)
                            .addComponent(addVipBorder, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGroup(vipPanelLayout.createSequentialGroup()
                            .addGap(14, 14, 14)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(34, 34, 34)
                            .addComponent(indicatorVipLabel)
                            .addGap(5, 5, 5)
                            .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(12, 12, 12)
                            .addGroup(vipPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(vipPanelLayout.createSequentialGroup()
                                    .addGap(3, 3, 3)
                                    .addComponent(numVip))
                                .addComponent(numViptxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(6, 6, 6)
                            .addGroup(vipPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(vipPanelLayout.createSequentialGroup()
                                    .addGap(3, 3, 3)
                                    .addComponent(nomVip))
                                .addComponent(nomViptxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(6, 6, 6)
                            .addGroup(vipPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(vipPanelLayout.createSequentialGroup()
                                    .addGap(3, 3, 3)
                                    .addComponent(prenomVip))
                                .addComponent(prenomViptxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(6, 6, 6)
                            .addGroup(vipPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(vipPanelLayout.createSequentialGroup()
                                    .addGap(3, 3, 3)
                                    .addComponent(civiliteVip))
                                .addComponent(civiliteVipbox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(vipPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(naissanceVip1)
                                .addComponent(naissanceViptxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(9, 9, 9)
                            .addGroup(vipPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(vipPanelLayout.createSequentialGroup()
                                    .addGap(3, 3, 3)
                                    .addComponent(naissanceVip))
                                .addComponent(datenaissanceVip, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(8, 8, 8)
                            .addGroup(vipPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(vipPanelLayout.createSequentialGroup()
                                    .addGap(3, 3, 3)
                                    .addComponent(roleVip))
                                .addComponent(roleVipbox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(11, 11, 11)
                            .addGroup(vipPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(vipPanelLayout.createSequentialGroup()
                                    .addGap(3, 3, 3)
                                    .addComponent(nationaliteVip))
                                .addComponent(nationaliteVipbox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(18, 18, 18)
                            .addGroup(vipPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(statutVip)
                                .addComponent(statutVipbox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(33, 33, 33)
                            .addGroup(vipPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(addBtn)
                                .addComponent(saveBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(vipPanelLayout.createSequentialGroup()
                                    .addGap(10, 10, 10)
                                    .addGroup(vipPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(addBaselbl)
                                        .addComponent(sauvegarderTxt))))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(11, 11, 11)
                .addGroup(vipPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(resetBtn)
                    .addComponent(delBtn)
                    .addComponent(svBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(vipPanelLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(vipPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(svLb)))))
        );

        eventTab.addTab("Gestion des VIP", new javax.swing.ImageIcon(getClass().getResource("/lux.png")), vipPanel); // NOI18N

        importPhotos.setText("Ajouter une photo");
        importPhotos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                importPhotosActionPerformed(evt);
            }
        });

        etatUpload.setText("Etat de l'upload : ");

        javax.swing.GroupLayout photoPanelLayout = new javax.swing.GroupLayout(photoPanel);
        photoPanel.setLayout(photoPanelLayout);
        photoPanelLayout.setHorizontalGroup(
            photoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(photoPanelLayout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addGroup(photoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(etatUpload)
                    .addGroup(photoPanelLayout.createSequentialGroup()
                        .addComponent(pathField, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(importPhotos)))
                .addContainerGap(1126, Short.MAX_VALUE))
        );
        photoPanelLayout.setVerticalGroup(
            photoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(photoPanelLayout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(photoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(pathField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(importPhotos))
                .addGap(18, 18, 18)
                .addComponent(etatUpload)
                .addContainerGap(559, Short.MAX_VALUE))
        );

        eventTab.addTab("Gestion des photos", new javax.swing.ImageIcon(getClass().getResource("/photo.png")), photoPanel); // NOI18N

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel11.setText("Liste des Vips");

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel13.setText("Ajouter un évènement || Mariage ou Divorce");

        jLabel14.setText("Numéro VIP 1");

        jLabel15.setText("Numéro VIP 2");

        applyThis.setText("Appliquer l'évènement");
        applyThis.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                applyThisActionPerformed(evt);
            }
        });

        jLabel16.setText("Lieu de l'évènement ");

        jLabel17.setText("Date du Mariage");

        jLabel18.setText("Date du Divorce");

        dateDtxt.setEnabled(false);

        nomVipE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nomVipEActionPerformed(evt);
            }
        });

        typeEvent.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Mariage", "Divorce" }));
        typeEvent.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                typeEventActionPerformed(evt);
            }
        });

        jLabel8.setText("Type d'évènement : ");

        applyEvent.setText("Appliquer");
        applyEvent.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                applyEventActionPerformed(evt);
            }
        });

        resetEvent.setText("Réinitaliser les champs ");
        resetEvent.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetEventActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelCelibLayout = new javax.swing.GroupLayout(panelCelib);
        panelCelib.setLayout(panelCelibLayout);
        panelCelibLayout.setHorizontalGroup(
            panelCelibLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSeparator8, javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(panelCelibLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelCelibLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel13)
                    .addGroup(panelCelibLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelCelibLayout.createSequentialGroup()
                            .addGroup(panelCelibLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel8)
                                .addComponent(jLabel14))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(typeEvent, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(applyEvent)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(resetEvent, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelCelibLayout.createSequentialGroup()
                            .addComponent(nomVipE, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(panelCelibLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel15)
                                .addComponent(nomVipE2, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(18, 18, 18)
                            .addGroup(panelCelibLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(lieuTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel16))
                            .addGap(18, 18, 18)
                            .addGroup(panelCelibLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(dateMtxt, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel17))
                            .addGap(18, 18, 18)
                            .addGroup(panelCelibLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(panelCelibLayout.createSequentialGroup()
                                    .addComponent(dateDtxt, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(27, 27, 27)
                                    .addComponent(applyThis, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(jLabel18)))))
                .addContainerGap(38, Short.MAX_VALUE))
        );
        panelCelibLayout.setVerticalGroup(
            panelCelibLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelCelibLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator8, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelCelibLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(typeEvent, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(applyEvent)
                    .addComponent(resetEvent))
                .addGap(18, 18, 18)
                .addGroup(panelCelibLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelCelibLayout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addGroup(panelCelibLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(panelCelibLayout.createSequentialGroup()
                                .addComponent(jLabel14)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(nomVipE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelCelibLayout.createSequentialGroup()
                                .addComponent(jLabel16)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelCelibLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(lieuTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(nomVipE2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(panelCelibLayout.createSequentialGroup()
                                .addGroup(panelCelibLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel17)
                                    .addComponent(jLabel18))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(panelCelibLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(dateMtxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(dateDtxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(applyThis)))
                    .addComponent(jLabel15))
                .addContainerGap(48, Short.MAX_VALUE))
        );

        tableEvent.setModel(modeleVipEvent);
        jScrollPane12.setViewportView(tableEvent);

        modifierVip1.setText("Assigner VIP 1");
        modifierVip1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modifierVip1ActionPerformed(evt);
            }
        });

        modifierVip2.setText("Assigner VIP 2");
        modifierVip2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modifierVip2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout eventPanelLayout = new javax.swing.GroupLayout(eventPanel);
        eventPanel.setLayout(eventPanelLayout);
        eventPanelLayout.setHorizontalGroup(
            eventPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(eventPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(eventPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator6, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane12, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 305, Short.MAX_VALUE)
                    .addGroup(eventPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(modifierVip2)
                        .addComponent(modifierVip1)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 86, Short.MAX_VALUE)
                .addComponent(panelCelib, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41))
        );
        eventPanelLayout.setVerticalGroup(
            eventPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(eventPanelLayout.createSequentialGroup()
                .addGroup(eventPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(eventPanelLayout.createSequentialGroup()
                        .addContainerGap(19, Short.MAX_VALUE)
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator6, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane12, javax.swing.GroupLayout.PREFERRED_SIZE, 510, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(eventPanelLayout.createSequentialGroup()
                        .addComponent(panelCelib, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(18, 18, 18)
                .addComponent(modifierVip1)
                .addGap(13, 13, 13)
                .addComponent(modifierVip2))
        );

        eventTab.addTab("Evènements et informations", new javax.swing.ImageIcon(getClass().getResource("/medical.png")), eventPanel); // NOI18N

        tableFilm.setModel(modeleFilm);
        jScrollPane2.setViewportView(tableFilm);

        delFilmBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/delete.png"))); // NOI18N
        delFilmBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delFilmBtnActionPerformed(evt);
            }
        });

        delBase.setText("Supprimer l'élément sélectionné");

        modifyFilm.setText("MODIFIER");
        modifyFilm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modifyFilmActionPerformed(evt);
            }
        });

        jLabel1.setText("Modifier un élément");

        addVipBorder1.setBackground(new java.awt.Color(102, 0, 102));

        javax.swing.GroupLayout addVipBorder1Layout = new javax.swing.GroupLayout(addVipBorder1);
        addVipBorder1.setLayout(addVipBorder1Layout);
        addVipBorder1Layout.setHorizontalGroup(
            addVipBorder1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        addVipBorder1Layout.setVerticalGroup(
            addVipBorder1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 388, Short.MAX_VALUE)
        );

        infoVipPanel1.setEditable(false);
        infoVipPanel1.setBackground(new java.awt.Color(240, 240, 240));
        infoVipPanel1.setColumns(20);
        infoVipPanel1.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        infoVipPanel1.setLineWrap(true);
        infoVipPanel1.setRows(5);
        infoVipPanel1.setToolTipText("");
        jScrollPane7.setViewportView(infoVipPanel1);

        infoLogo1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/info-icone-5376-48.png"))); // NOI18N

        numVisa.setText("Numéro Visa :");

        titreFilm.setText("Titre du film :");

        genreFilm.setText("Genre du film :");

        anneeSortie.setText("Année de sortie : ");

        genreFilmbox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }));

        addFilmBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cross.png"))); // NOI18N
        addFilmBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        addFilmBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addFilmBtnActionPerformed(evt);
            }
        });

        addBase.setText("Ajouter à la base");

        validateFilm.setText("VALIDER");
        validateFilm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                validateFilmActionPerformed(evt);
            }
        });

        jLabel4.setText("Appliquer");

        jTextArea1.setEditable(false);
        jTextArea1.setBackground(new java.awt.Color(240, 240, 240));
        jTextArea1.setColumns(12);
        jTextArea1.setRows(5);
        jScrollPane8.setViewportView(jTextArea1);

        jButton4.setText("Ajouter une photo");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        indicatorVipLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        indicatorVipLabel1.setText("Ajouter ou modifier un Film");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(addFilmBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(9, 9, 9)
                        .addComponent(addBase)))
                .addGap(27, 27, 27)
                .addComponent(validateFilm)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4)
                .addContainerGap(56, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addGap(168, 168, 168)
                            .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(indicatorVipLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 287, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel2Layout.createSequentialGroup()
                                    .addComponent(numVisa)
                                    .addGap(30, 30, 30)
                                    .addComponent(numVisatxt, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel2Layout.createSequentialGroup()
                                    .addComponent(titreFilm)
                                    .addGap(33, 33, 33)
                                    .addComponent(titreFilmtxt, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel2Layout.createSequentialGroup()
                                    .addComponent(genreFilm)
                                    .addGap(26, 26, 26)
                                    .addComponent(genreFilmbox, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel2Layout.createSequentialGroup()
                                    .addComponent(anneeSortie)
                                    .addGap(10, 10, 10)
                                    .addComponent(anneeSortietxt, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(257, Short.MAX_VALUE)
                .addComponent(jButton4)
                .addGap(74, 74, 74)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(addBase)
                        .addComponent(validateFilm, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel4))
                    .addComponent(addFilmBtn))
                .addGap(33, 33, 33))
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(indicatorVipLabel1)
                    .addGap(4, 4, 4)
                    .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addGap(3, 3, 3)
                            .addComponent(numVisa))
                        .addComponent(numVisatxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addGap(3, 3, 3)
                            .addComponent(titreFilm))
                        .addComponent(titreFilmtxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addGap(3, 3, 3)
                            .addComponent(genreFilm))
                        .addComponent(genreFilmbox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addGap(3, 3, 3)
                            .addComponent(anneeSortie))
                        .addComponent(anneeSortietxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(95, Short.MAX_VALUE)))
        );

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setText("Ajouter un acteur pour ce film :");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jList1.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane10.setViewportView(jList1);

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setText("Ajouter un réalisateur pour ce film :");

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jList5.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane11.setViewportView(jList5);

        jButton5.setText("Supprimer un acteur");

        jButton6.setText("Supprimer un réalisateur");

        jButton7.setText("Ajouter");

        jButton8.setText("Ajouter");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator5)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane11, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 365, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton5, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jButton6, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton7, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jButton8, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 365, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton7))
                .addGap(28, 28, 28)
                .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 17, Short.MAX_VALUE)
                .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel7)
                .addGap(32, 32, 32)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton8))
                .addGap(30, 30, 30)
                .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton6)
                .addGap(21, 21, 21))
        );

        javax.swing.GroupLayout filmPanelLayout = new javax.swing.GroupLayout(filmPanel);
        filmPanel.setLayout(filmPanelLayout);
        filmPanelLayout.setHorizontalGroup(
            filmPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(filmPanelLayout.createSequentialGroup()
                .addGroup(filmPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(filmPanelLayout.createSequentialGroup()
                        .addGroup(filmPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(filmPanelLayout.createSequentialGroup()
                                .addGap(20, 20, 20)
                                .addComponent(infoLogo1))
                            .addComponent(addVipBorder1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(12, 12, 12)
                        .addGroup(filmPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(45, 45, 45)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 548, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, filmPanelLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(delFilmBtn)
                        .addGap(18, 18, 18)
                        .addComponent(delBase)
                        .addGap(133, 133, 133)
                        .addComponent(modifyFilm, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel1)
                        .addGap(55, 55, 55)))
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49))
        );
        filmPanelLayout.setVerticalGroup(
            filmPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(filmPanelLayout.createSequentialGroup()
                .addGroup(filmPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(filmPanelLayout.createSequentialGroup()
                        .addGap(60, 60, 60)
                        .addComponent(infoLogo1)
                        .addGap(52, 52, 52)
                        .addComponent(addVipBorder1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(filmPanelLayout.createSequentialGroup()
                        .addGap(160, 160, 160)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(filmPanelLayout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(filmPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(filmPanelLayout.createSequentialGroup()
                                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(filmPanelLayout.createSequentialGroup()
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 521, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(filmPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, filmPanelLayout.createSequentialGroup()
                                        .addGroup(filmPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(modifyFilm, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel1)
                                            .addComponent(delBase))
                                        .addGap(27, 27, 27))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, filmPanelLayout.createSequentialGroup()
                                        .addComponent(delFilmBtn)
                                        .addGap(40, 40, 40)))))))
                .addContainerGap())
        );

        eventTab.addTab("Gestion des Films", filmPanel);

        lblDispo2.setText("Cette page sera bientôt disponible !");

        javax.swing.GroupLayout acteurPanelLayout = new javax.swing.GroupLayout(acteurPanel);
        acteurPanel.setLayout(acteurPanelLayout);
        acteurPanelLayout.setHorizontalGroup(
            acteurPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(acteurPanelLayout.createSequentialGroup()
                .addGap(494, 494, 494)
                .addComponent(lblDispo2)
                .addContainerGap(839, Short.MAX_VALUE))
        );
        acteurPanelLayout.setVerticalGroup(
            acteurPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(acteurPanelLayout.createSequentialGroup()
                .addGap(215, 215, 215)
                .addComponent(lblDispo2)
                .addContainerGap(426, Short.MAX_VALUE))
        );

        eventTab.addTab("Gestion des Acteurs - Réalisateurs", acteurPanel);

        lblDispo1.setText("Cette page sera bientôt disponible !");

        javax.swing.GroupLayout reaPanelLayout = new javax.swing.GroupLayout(reaPanel);
        reaPanel.setLayout(reaPanelLayout);
        reaPanelLayout.setHorizontalGroup(
            reaPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(reaPanelLayout.createSequentialGroup()
                .addGap(494, 494, 494)
                .addComponent(lblDispo1)
                .addContainerGap(839, Short.MAX_VALUE))
        );
        reaPanelLayout.setVerticalGroup(
            reaPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(reaPanelLayout.createSequentialGroup()
                .addGap(215, 215, 215)
                .addComponent(lblDispo1)
                .addContainerGap(426, Short.MAX_VALUE))
        );

        eventTab.addTab("Gestion des Réalisateurs", reaPanel);

        topPanel.setBackground(new java.awt.Color(102, 0, 102));
        topPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setFont(new java.awt.Font("Segoe UI Symbol", 0, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Voicela Administration Tool v0.1");
        topPanel.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(88, 29, -1, -1));

        baseNameTxt.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        baseNameTxt.setForeground(new java.awt.Color(255, 255, 255));
        baseNameTxt.setText("Nom d'utilisateur");
        topPanel.add(baseNameTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(177, 72, -1, -1));

        baseIndicTxt.setForeground(new java.awt.Color(255, 255, 255));
        baseIndicTxt.setText("Nom de la base : ");
        topPanel.add(baseIndicTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(88, 75, -1, -1));

        borderLeftYellowPanel.setBackground(new java.awt.Color(255, 215, 0));

        javax.swing.GroupLayout borderLeftYellowPanelLayout = new javax.swing.GroupLayout(borderLeftYellowPanel);
        borderLeftYellowPanel.setLayout(borderLeftYellowPanelLayout);
        borderLeftYellowPanelLayout.setHorizontalGroup(
            borderLeftYellowPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        borderLeftYellowPanelLayout.setVerticalGroup(
            borderLeftYellowPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        topPanel.add(borderLeftYellowPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 20, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(eventTab, javax.swing.GroupLayout.PREFERRED_SIZE, 1510, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 15, Short.MAX_VALUE))
            .addComponent(topPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(topPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(eventTab, javax.swing.GroupLayout.PREFERRED_SIZE, 693, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        eventTab.getAccessibleContext().setAccessibleDescription("");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void svBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_svBtnActionPerformed
        
        int ligne = tableVip.getSelectedRow();
        Vip temp = modeleVip.getSelectedVip(ligne);
        numViptxt.setText(temp.getNumVip());
        nomViptxt.setText(temp.getNomVip());
        prenomViptxt.setText(temp.getPrenomVip());
        civiliteVipbox.setSelectedItem(temp.getCivilite());
        java.sql.Date d2 = new java.sql.Date(1970-01-01);
         
        naissanceViptxt.setDate(d2);
       
        datenaissanceVip.setText(temp.getLieuNaissance());
        roleVipbox.setSelectedItem(temp.getCodeRole());
        addBtn.setEnabled(false);
        addBaselbl.setEnabled(false);
        
       // civiliteVipbox.set

        
    }//GEN-LAST:event_svBtnActionPerformed

    private void delBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delBtnActionPerformed

        try {
            int ligne = tableVip.getSelectedRow();
            modeleVip.delVip(ligne);
            JOptionPane.showMessageDialog(this, "VIP supprimé avec succès ! ", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex) {
            Logger.getLogger(MainScreen.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_delBtnActionPerformed

    private void resetBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetBtnActionPerformed
        addBtn.setEnabled(true);
        addBaselbl.setEnabled(true);
         java.sql.Date d2 = new java.sql.Date(1970-01-01);
        nomViptxt.setText("");
        prenomViptxt.setText("");
        datenaissanceVip.setText("");
        naissanceViptxt.setDate(d2);
        modeleVip.refreshVip();

        JOptionPane.showMessageDialog(this, "Les champs ont été réinitialisés et la vue actualisée.", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_resetBtnActionPerformed

    private void addBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addBtnActionPerformed
        try {

            if (numViptxt.getText().isEmpty()) {
                throw new Exception("Le champ numéro doit pas être vide");
            }
            //leVip.setNumVip(numViptxt.getText());
            String a = numViptxt.getText();

            if (nomViptxt.getText().isEmpty()){
                throw new Exception("Le champ nom ne doit pas être vide");
            }
            //leVip.setNomVip(nomViptxt.getText());
            String b = nomViptxt.getText().toUpperCase();

            if (prenomViptxt.getText().isEmpty()){
                throw new Exception("Le champ prénom ne doit pas être vide");
            }
            //leVip.setPrenomVip(prenomViptxt.getText());
            String c = prenomViptxt.getText().substring(0,1).toUpperCase() + prenomViptxt.getText().substring(1).toLowerCase();

            //leVip.setCivilite(civiliteVipbox.getSelectedItem().toString());
            String d = civiliteVipbox.getSelectedItem().toString().substring(0,1);

            if (datenaissanceVip.getText().isEmpty()){
                throw new Exception("Ce champ ne doit pas être vide");
            }
            //leVip.setDateNaissance(datenaissanceVip.getText());
            String f = datenaissanceVip.getText();

            if (naissanceViptxt.getCalendar()==null){
                throw new Exception("Ce champ ne doit pas être vide");
            }
            //leVip.setLieuNaissance(naissanceViptxt.getText());
            java.sql.Date d2 = new java.sql.Date(naissanceViptxt.getDate().getTime());
            String e = d2.toString();

            //leVip.setCodeRole(roleVipbox.getSelectedItem().toString());
            String g = roleVipbox.getSelectedItem().toString().substring(0,2);

            //leVip.setCodeStatut(statutVipbox.getSelectedItem().toString());
            String h = statutVipbox.getSelectedItem().toString().substring(0,1);
            String h1 = "C";

            //leVip.setNationalite(nationaliteVipbox.getSelectedItem().toString());
            String i = nationaliteVipbox.getSelectedItem().toString().substring(0,2);
            
            String j = "P00.jpg";

            System.out.println(i);
            leVip = new Vip(a,b,c,d,e,f,g,h1,i,j);
            modeleVip.addVip(leVip);

            JOptionPane.showMessageDialog(this, "Votre requête a bien été ajoutée à la base. ", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erreur : " + e.getMessage(), "Erreur", JOptionPane.WARNING_MESSAGE);
        }

        lastNumVip = lastNumVip +1;
        numViptxt.setText("0"+String.valueOf(lastNumVip));

    }//GEN-LAST:event_addBtnActionPerformed

    private void statutVipboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_statutVipboxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_statutVipboxActionPerformed

    private void nationaliteVipboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nationaliteVipboxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nationaliteVipboxActionPerformed

    private void roleVipboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_roleVipboxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_roleVipboxActionPerformed

    private void civiliteVipboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_civiliteVipboxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_civiliteVipboxActionPerformed

    private void nomViptxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nomViptxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nomViptxtActionPerformed

    private void numViptxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_numViptxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_numViptxtActionPerformed

    private void saveBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveBtnActionPerformed
        addBtn.setEnabled(true);
        addBaselbl.setEnabled(true);        
        java.sql.Date d2 = new java.sql.Date(naissanceViptxt.getDate().getTime());
        String dateN = (String) d2.toString();
        int ligne = tableVip.getSelectedRow();
        try {
            modeleVip.modifyVip(ligne, numViptxt.getText(), nomViptxt.getText(), prenomViptxt.getText(), civiliteVipbox.getSelectedItem().toString().substring(0,1), dateN, datenaissanceVip.getText(), roleVipbox.getSelectedItem().toString().substring(0,2),statutVipbox.getSelectedItem().toString().substring(0,1), nationaliteVipbox.getSelectedItem().toString().substring(0,2));
        } catch (SQLException ex) {
            Logger.getLogger(MainScreen.class.getName()).log(Level.SEVERE, null, ex);
        }
        JOptionPane.showMessageDialog(this, "VIP modifié avec succès ! ", "Confirmation", JOptionPane.INFORMATION_MESSAGE);



        
    }//GEN-LAST:event_saveBtnActionPerformed

    private void addFilmBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addFilmBtnActionPerformed
     
    try{
        if (numVisatxt.getText().isEmpty()) {
            throw new Exception("Le champ numéro doit pas être vide");
        } 
        String numVisa = numVisatxt.getText();
        
        if(titreFilmtxt.getText().isEmpty()){
            throw new Exception("Le champ titrefilm doit pas être vide");
        }
        String titre = titreFilmtxt.getText();
        
        String idGenre = genreFilmbox.getSelectedItem().toString();
        
        if(anneeSortietxt.getText().isEmpty()){
            throw new Exception("Le champ anneesortie doit pas être vide");
        }
        String anneesortie = anneeSortietxt.getText();
        
        Film leFilm = new Film(numVisa, titre, idGenre, Integer.parseInt(anneesortie),"000000.jpg");
        modeleFilm.addFilm(leFilm);
        
    JOptionPane.showMessageDialog(this, "Votre requête a bien été ajoutée à la base. ", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
    } catch(Exception e){
        JOptionPane.showMessageDialog(this, e.getMessage() + "Erreur ", e.getMessage() + "Erreur", JOptionPane.ERROR_MESSAGE);
    }



    }//GEN-LAST:event_addFilmBtnActionPerformed

    private void delFilmBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delFilmBtnActionPerformed
       try {
            int ligne = tableFilm.getSelectedRow();
            modeleFilm.delFilm(ligne);
            JOptionPane.showMessageDialog(this, "Film supprimé avec succès ! ", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex) {
            Logger.getLogger(MainScreen.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_delFilmBtnActionPerformed

    private void modifyFilmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modifyFilmActionPerformed
        int ligne = tableFilm.getSelectedRow();
        Film temp = modeleFilm.getSelectedFilm(ligne);
        numVisatxt.setText(temp.getNumVisa());
        titreFilmtxt.setText(temp.getTitreFilm());
        genreFilmbox.setSelectedItem(temp.getIdGenre());
        anneeSortietxt.setText(temp.getAnneeSortie()+"");
        
    }//GEN-LAST:event_modifyFilmActionPerformed

    private void validateFilmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_validateFilmActionPerformed

         
        try {
            int ligne = tableFilm.getSelectedRow();
            modeleFilm.modifyFilm(ligne, numVisatxt.getText(),titreFilmtxt.getText(),genreFilmbox.getSelectedItem().toString(), Integer.parseInt(anneeSortietxt.getText()));
        } catch (SQLException ex) {
            System.out.println("Erreur : " + ex.getMessage());
        }
        JOptionPane.showMessageDialog(this, "Film modifié avec succès ! ", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_validateFilmActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void modifierVip1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modifierVip1ActionPerformed
        int ligne = tableEvent.getSelectedRow();
        Vip temp = modeleVipEvent.getSelectedVip(ligne);

        
        try {   
            String index = temp.getNumVip();
            Evenement event = modeleVipEvent.getSelectedVipEvent(index);
            String numVipE = temp.getNumVip();            
            if(event!=null){

                lieuTxt.setText(event.getLieuMariage());
                nomVipE2.setText(event.getNumVipConjoint());
                dateMtxt.setText(event.getDateMariage());
                dateDtxt.setText(event.getDateDivorce());               
            }
            nomVipE.setText(temp.getNumVip());
        
        
        } catch (Exception e){
            
             JOptionPane.showMessageDialog(this, "Veuillez sélectionner un autre Vip. " + e.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_modifierVip1ActionPerformed

    private void nomVipEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nomVipEActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nomVipEActionPerformed

    private void modifierVip2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modifierVip2ActionPerformed
        int ligne = tableEvent.getSelectedRow();
        Vip temp = modeleVipEvent.getSelectedVip(ligne);
        String numVipE2 = temp.getNumVip();
        try {           
        nomVipE2.setText(temp.getNumVip());
     
        
        } catch (Exception e){
             JOptionPane.showMessageDialog(this, "Veuillez sélectionner un autre Vip.", "Erreur", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_modifierVip2ActionPerformed

    private void applyThisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_applyThisActionPerformed

        
        try {
            Evenement ev;
            String a = nomVipE.getText();
            String b = nomVipE2.getText();
            String c = lieuTxt.getText();
            String d = dateMtxt.getText();
            String e = dateDtxt.getText();
            ev = new Evenement(a,d,b,c,e);

            daoEvent.addEvent(ev);
            JOptionPane.showMessageDialog(this,"Evènement ajouté", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erreur SQL : " + ex.getMessage() , "Erreur", JOptionPane.ERROR_MESSAGE);
            Logger.getLogger(MainScreen.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception e){
            JOptionPane.showMessageDialog(this, "Erreur NON SQL : " + e.getMessage() , "Erreur", JOptionPane.ERROR_MESSAGE);
            Logger.getLogger(MainScreen.class.getName()).log(Level.SEVERE, null, e);
        }
        
        
        
    }//GEN-LAST:event_applyThisActionPerformed

    private void applyEventActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_applyEventActionPerformed
            
        String typeEv = (String) typeEvent.getSelectedItem();
        
        if(typeEv == "Mariage"){
            dateDtxt.setEnabled(false);
            dateMtxt.setEnabled(true);
            dateDtxt.setText("1000-01-01");
        } 
        
        if(typeEv == "Divorce"){
            dateDtxt.setEnabled(true);
            dateMtxt.setEnabled(false);
            //dateMtxt.setText("2015-10-10");
        }
        
        
    }//GEN-LAST:event_applyEventActionPerformed

    private void resetEventActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetEventActionPerformed
        String reset = null;
        nomVipE.setText(reset);
        nomVipE2.setText(reset);
        lieuTxt.setText(reset);
        dateMtxt.setText(reset);
        dateDtxt.setText(reset);
    }//GEN-LAST:event_resetEventActionPerformed

    private void typeEventActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_typeEventActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_typeEventActionPerformed

    private void importPhotosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_importPhotosActionPerformed
        etatUpload.setText(("Etat upload : Veuillez choisir un fichier"));
        FTPManager fileUpload;
        JFileChooser fileChooser = new JFileChooser();
        int returnValue = fileChooser.showOpenDialog(null);
        if (returnValue == JFileChooser.APPROVE_OPTION) {
            
            File selectedFile = fileChooser.getSelectedFile();
            String fileName = selectedFile.getName();
            String filePath = fileChooser.getSelectedFile().getAbsolutePath();
            System.out.println(selectedFile.getName());
            pathField.setText(filePath);
            fileUpload = new FTPManager(filePath,fileName);
        }

        etatUpload.setText(("Etat upload : Upload de la photo réussie !"));
    }//GEN-LAST:event_importPhotosActionPerformed

    
    /**
     * @param args the command line arguments
     */



    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel acteurPanel;
    private javax.swing.JLabel addBase;
    private javax.swing.JLabel addBaselbl;
    private javax.swing.JButton addBtn;
    private javax.swing.JButton addFilmBtn;
    private javax.swing.JPanel addVipBorder;
    private javax.swing.JPanel addVipBorder1;
    private javax.swing.JLabel anneeSortie;
    private javax.swing.JTextField anneeSortietxt;
    private javax.swing.JButton applyEvent;
    private javax.swing.JButton applyThis;
    private javax.swing.JLabel baseIndicTxt;
    private javax.swing.JLabel baseNameTxt;
    private javax.swing.JPanel borderLeftYellowPanel;
    private javax.swing.JLabel civiliteVip;
    private javax.swing.JComboBox<String> civiliteVipbox;
    private javax.swing.JTextField dateDtxt;
    private javax.swing.JTextField dateMtxt;
    private javax.swing.JTextField datenaissanceVip;
    private javax.swing.JLabel delBase;
    private javax.swing.JButton delBtn;
    private javax.swing.JButton delFilmBtn;
    private javax.swing.JLabel etatUpload;
    private javax.swing.JPanel eventPanel;
    private javax.swing.JTabbedPane eventTab;
    private javax.swing.JPanel filmPanel;
    private javax.swing.JLabel genreFilm;
    private javax.swing.JComboBox<String> genreFilmbox;
    private javax.swing.JButton importPhotos;
    private javax.swing.JLabel indicatorVipLabel;
    private javax.swing.JLabel indicatorVipLabel1;
    private javax.swing.JLabel infoLogo;
    private javax.swing.JLabel infoLogo1;
    private javax.swing.JTextArea infoVipPanel;
    private javax.swing.JTextArea infoVipPanel1;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JList<String> jList1;
    private javax.swing.JList<String> jList5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane12;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JLabel lblDispo1;
    private javax.swing.JLabel lblDispo2;
    private javax.swing.JTextField lieuTxt;
    private javax.swing.JButton modifierVip1;
    private javax.swing.JButton modifierVip2;
    private javax.swing.JButton modifyFilm;
    private javax.swing.JLabel naissanceVip;
    private javax.swing.JLabel naissanceVip1;
    private com.toedter.calendar.JDateChooser naissanceViptxt;
    private javax.swing.JLabel nationaliteVip;
    private javax.swing.JComboBox<String> nationaliteVipbox;
    private javax.swing.JLabel nomVip;
    private javax.swing.JTextField nomVipE;
    private javax.swing.JTextField nomVipE2;
    private javax.swing.JTextField nomViptxt;
    private javax.swing.JLabel numVip;
    private javax.swing.JTextField numViptxt;
    private javax.swing.JLabel numVisa;
    private javax.swing.JTextField numVisatxt;
    private javax.swing.JPanel panelCelib;
    private javax.swing.JTextField pathField;
    private javax.swing.JPanel photoPanel;
    private javax.swing.JLabel prenomVip;
    private javax.swing.JTextField prenomViptxt;
    private javax.swing.JPanel reaPanel;
    private javax.swing.JButton resetBtn;
    private javax.swing.JButton resetEvent;
    private javax.swing.JLabel roleVip;
    private javax.swing.JComboBox<String> roleVipbox;
    private javax.swing.JLabel sauvegarderTxt;
    private javax.swing.JButton saveBtn;
    private javax.swing.JLabel statutVip;
    private javax.swing.JComboBox<String> statutVipbox;
    private javax.swing.JButton svBtn;
    private javax.swing.JLabel svLb;
    private javax.swing.JTable tableEvent;
    private javax.swing.JTable tableFilm;
    private javax.swing.JTable tableVip;
    private javax.swing.JLabel titreFilm;
    private javax.swing.JTextField titreFilmtxt;
    private javax.swing.JPanel topPanel;
    private javax.swing.JComboBox<String> typeEvent;
    private javax.swing.JButton validateFilm;
    private javax.swing.JPanel vipPanel;
    // End of variables declaration//GEN-END:variables
}
